We regret for the issue that you are facing, Thanks for helping us by raising an issue so that we can improve ourself to do the best.
Mark one of the issues given below with respect to the issue you are facing with:

- [ ] Issue facing with setup of KOB-email-verification 
- [ ] Other issues: please provide the issue in the comment box

____________________________________________________________________________________

### Please explain the Issue / Feature Request here:

____________________________________________________________________________________
### Please provide the necessary screenshots or documents regarding the issue:
